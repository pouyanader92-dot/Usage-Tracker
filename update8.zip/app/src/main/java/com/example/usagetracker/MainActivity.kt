package com.example.usagetracker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Tracker.ensureRunning(this)   // ثبت خودکار، بدون سوییچ
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(
                    colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Navy)
                ) { Screen() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Tracker.ensureRunning(this)
    }
}

private val Navy = Color(0xFF050B1F)
private val NavyLight = Color(0xFF0A1A4A)
private val CardBg = Color(0xFF0E1B3D)
private val CardBorder = Color(0xFF1B2F6B)
private val Track = Color(0xFF16254F)
private val Cyan = Color(0xFF22D3EE)
private val Blue = Color(0xFF2563EB)
private val PastBar = Color(0xFF2B4FA8)
private val TextMain = Color(0xFFE6EEFF)
private val TextDim = Color(0xFF8FA3CC)
private val Amber = Color(0xFFFBBF24)
private val Red = Color(0xFFF87171)

private val fa = Locale("fa")

private fun fmt(ms: Long): String {
    val nf = NumberFormat.getInstance(fa)
    val m = ms / 60000
    val h = m / 60
    val mm = m % 60
    return when {
        m == 0L -> if (ms > 0) "کمتر از یک دقیقه" else "۰ دقیقه"
        h == 0L -> "${nf.format(mm)} دقیقه"
        else -> "${nf.format(h)} ساعت و ${nf.format(mm)} دقیقه"
    }
}

private fun clock(ms: Long): String {
    val nf = NumberFormat.getInstance(fa).apply { minimumIntegerDigits = 2; isGroupingUsed = false }
    val t = maxOf(ms, 0L) / 1000
    return "${nf.format(t / 3600)}:${nf.format(t % 3600 / 60)}:${nf.format(t % 60)}"
}

/** ساعت:دقیقه، مثل ۲:۱۵ */
private fun hm(ms: Long): String {
    val nh = NumberFormat.getInstance(fa).apply { isGroupingUsed = false }
    val nm = NumberFormat.getInstance(fa).apply { minimumIntegerDigits = 2; isGroupingUsed = false }
    val m = ms / 60000
    return "${nh.format(m / 60)}:${nm.format(m % 60)}"
}

private fun dayLetter(ms: Long): String {
    val d = Calendar.getInstance().apply { timeInMillis = ms }.get(Calendar.DAY_OF_WEEK)
    return when (d) {
        Calendar.SATURDAY -> "ش"
        Calendar.SUNDAY -> "ی"
        Calendar.MONDAY -> "د"
        Calendar.TUESDAY -> "س"
        Calendar.WEDNESDAY -> "چ"
        Calendar.THURSDAY -> "پ"
        else -> "ج"
    }
}

private data class Snap(
    val totals: List<Pair<Long, Long>>,
    val sessions: List<Pair<Long, Long>>,
    val openStart: Long,
    val usageOk: Boolean,
    val topApps: List<Triple<String, String, Long>>,
    val history: List<Pair<Long, Long>>
)

@Composable
private fun AppCard(content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.fillMaxWidth()
            .clip(shape)
            .background(CardBg)
            .border(1.dp, CardBorder, shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
private fun Ring(
    progress: Float,
    color: Color,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 14.dp.toPx()
            val tl = Offset(stroke / 2, stroke / 2)
            val sz = Size(size.width - stroke, size.height - stroke)
            drawArc(
                color = Track, startAngle = -90f, sweepAngle = 360f, useCenter = false,
                topLeft = tl, size = sz, style = Stroke(width = stroke)
            )
            if (progress > 0f) {
                drawArc(
                    color = color, startAngle = -90f, sweepAngle = 360f * progress, useCenter = false,
                    topLeft = tl, size = sz, style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, content = content)
    }
}

@Composable
private fun StepButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(42.dp, 34.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (enabled) Track else Track.copy(alpha = 0.5f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = if (enabled) Cyan else TextDim, fontSize = 18.sp) }
}

private val weekOrder = listOf(
    Calendar.SATURDAY to "شنبه", Calendar.SUNDAY to "یکشنبه", Calendar.MONDAY to "دوشنبه",
    Calendar.TUESDAY to "سه‌شنبه", Calendar.WEDNESDAY to "چهارشنبه",
    Calendar.THURSDAY to "پنجشنبه", Calendar.FRIDAY to "جمعه"
)

@Composable
private fun AppIcon(pkg: String) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        runCatching { ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
    }
    if (bmp != null) {
        Image(bmp, contentDescription = null, modifier = Modifier.size(36.dp))
    } else {
        Spacer(Modifier.size(36.dp))
    }
}

@Composable
private fun Screen() {
    val ctx = LocalContext.current
    var snap by remember { mutableStateOf<Snap?>(null) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var batteryOk by remember { mutableStateOf(true) }
    var limits by remember { mutableStateOf(Tracker.allLimits(ctx)) }
    var backupOk by remember { mutableStateOf(Backup.hasPermission()) }
    var historyOpen by remember { mutableStateOf(false) }
    var botPlatform by remember { mutableStateOf(Report.platform(ctx)) }
    var botToken by remember { mutableStateOf(Report.token(ctx)) }
    var botChat by remember { mutableStateOf(Report.chatId(ctx)) }
    var reportHour by remember { mutableStateOf(Report.hour(ctx)) }
    var botStatus by remember { mutableStateOf(Report.lastStatus(ctx)) }
    val scope = rememberCoroutineScope()
    var editable by remember { mutableStateOf(Tracker.canEditSettings(ctx)) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    LaunchedEffect(Unit) {
        while (true) {
            snap = withContext(Dispatchers.IO) {
                Backup.restoreIfNeeded(ctx)
                val usageOk = UsageSource.hasAccess(ctx)
                val pm = ctx.packageManager
                val top = if (usageOk) {
                    UsageSource.todayPerApp(ctx).entries
                        .sortedByDescending { it.value }
                        .take(5)
                        .map { (pkg, ms) ->
                            val label = runCatching { pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString() }
                                .getOrDefault(pkg)
                            Triple(pkg, label, ms)
                        }
                } else emptyList()
                Snap(
                    Tracker.dailyTotals(ctx), Tracker.todaySessions(ctx), Tracker.openStart(ctx),
                    usageOk, top, History.list(ctx)
                )
            }
            now = System.currentTimeMillis()
            batteryOk = ctx.getSystemService(PowerManager::class.java)
                .isIgnoringBatteryOptimizations(ctx.packageName)
            editable = Tracker.canEditSettings(ctx)
            limits = Tracker.allLimits(ctx)
            backupOk = Backup.hasPermission()
            delay(1000)
        }
    }

    val s = snap
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Navy, NavyLight)))) {
        if (s == null) return@Box
        val active = s.openStart > 0L
        val total = s.totals.first().second
        val dow = Calendar.getInstance().apply { timeInMillis = now }.get(Calendar.DAY_OF_WEEK)
        val limit = limits[dow - 1]
        val limitMs = limit * 60_000L
        val over = limitMs > 0 && total >= limitMs
        val progress = if (limitMs > 0) (total.toFloat() / limitMs).coerceIn(0f, 1f) else 0f
        val ringColor = when {
            over -> Red
            progress >= 0.8f -> Amber
            else -> Cyan
        }

        Column(
            Modifier.fillMaxSize().statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // سربرگ
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.logo), contentDescription = null, modifier = Modifier.size(46.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("UsageTracker", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("ثبت زمان استفاده از گوشی", color = TextDim, fontSize = 13.sp)
                }
            }

            // هشدار باتری
            if (!batteryOk) {
                AppCard {
                    Text("برای کار در پس‌زمینه، محدودیت باتری باید برداشته بشه.", color = Amber)
                    Button(
                        onClick = {
                            ctx.startActivity(
                                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                                    .setData(Uri.parse("package:${ctx.packageName}"))
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)
                    ) { Text("اجازه دادن") }
                }
            }

            // کارت اصلی: حلقه‌ی پیشرفت + جلسه‌ی فعلی
            AppCard {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Ring(progress, ringColor, Modifier.size(150.dp)) {
                        Text(hm(total), color = TextMain, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text("امروز", color = TextDim, fontSize = 12.sp)
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(if (active) "جلسه‌ی فعلی" else "گوشی قفل است", color = TextDim, fontSize = 13.sp)
                        if (active) {
                            Text(clock(now - s.openStart), color = Cyan, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        }
                        if (limitMs > 0) {
                            if (over) {
                                Text("از سقف گذشته: ${fmt(total - limitMs)}", color = Red, fontSize = 14.sp)
                            } else {
                                Text("مانده تا سقف: ${fmt(limitMs - total)}", color = TextMain, fontSize = 14.sp)
                            }
                        } else {
                            Text("سقف روزانه تعیین نشده", color = TextDim, fontSize = 13.sp)
                        }
                    }
                }
            }

            // پرمصرف‌ترین برنامه‌های امروز
            AppCard {
                Text("پرمصرف‌ترین برنامه‌های امروز", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                if (!s.usageOk) {
                    Text(
                        "برای اینکه آمار مثل Digital Wellbeing باشه و مصرف هر برنامه دیده بشه، دسترسی «Usage access» رو بده.",
                        color = Amber, fontSize = 13.sp
                    )
                    Button(
                        onClick = {
                            ctx.startActivity(
                                Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                                    .setData(Uri.parse("package:${ctx.packageName}"))
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)
                    ) { Text("دادن دسترسی") }
                } else if (s.topApps.isEmpty()) {
                    Text("هنوز مصرفی ثبت نشده", color = TextDim)
                } else {
                    val topMax = s.topApps.first().third.coerceAtLeast(1L)
                    s.topApps.forEach { (pkg, label, ms) ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            AppIcon(pkg)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(label, color = TextMain, fontSize = 14.sp)
                                Box(
                                    Modifier.fillMaxWidth().height(5.dp)
                                        .clip(RoundedCornerShape(3.dp)).background(Track)
                                ) {
                                    Box(
                                        Modifier.fillMaxWidth((ms.toFloat() / topMax).coerceIn(0.03f, 1f))
                                            .fillMaxHeight()
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(Brush.horizontalGradient(listOf(Blue, Cyan)))
                                    )
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(fmt(ms), color = Cyan, fontSize = 13.sp)
                        }
                    }
                }
            }

            // سقف هر روز هفته
            AppCard {
                Text("سقف استفاده‌ی هر روز هفته", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                weekOrder.forEach { (d, name) ->
                    val v = limits[d - 1]
                    val isToday = d == dow
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            name, modifier = Modifier.width(78.dp),
                            color = if (isToday) Cyan else TextMain,
                            fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal
                        )
                        StepButton("−", editable) {
                            val n = (v - 15).coerceAtLeast(0)
                            if (Tracker.setLimitFor(ctx, d, n)) limits = Tracker.allLimits(ctx)
                        }
                        Text(
                            if (v == 0) "بدون سقف" else fmt(v * 60_000L),
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center,
                            color = TextMain, fontSize = 15.sp
                        )
                        StepButton("+", editable) {
                            val n = (v + 15).coerceAtMost(720)
                            if (Tracker.setLimitFor(ctx, d, n)) limits = Tracker.allLimits(ctx)
                        }
                    }
                }
                if (editable) {
                    Text("الان می‌تونی سقف همه‌ی روزهای هفته رو تنظیم کنی.", color = Cyan, fontSize = 12.sp)
                } else {
                    Text(
                        "تنظیم سقف هفته فقط پنجشنبه‌ها از ساعت ۱۴ تا ۱۶ ممکنه " +
                            "(تاریخ و ساعت گوشی باید روی «خودکار» باشه).",
                        color = Amber, fontSize = 12.sp
                    )
                }
                Text("وقتی زمان امروز به سقف همون روز برسه، هشدار نشون داده می‌شه.", color = TextDim, fontSize = 12.sp)
            }

            // نمودار هفتگی
            AppCard {
                Text("۷ روز اخیر", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                val days = s.totals.asReversed()          // قدیمی‌ترین راست، امروز چپ
                fun limitOf(dayStart: Long): Long {
                    val d = Calendar.getInstance().apply { timeInMillis = dayStart }.get(Calendar.DAY_OF_WEEK)
                    return limits[d - 1] * 60_000L
                }
                val scaleMax = maxOf(days.maxOf { it.second }, days.maxOf { limitOf(it.first) })
                    .coerceAtLeast(60_000L)
                val barMax = 100f

                Row(Modifier.fillMaxWidth().height(130.dp)) {
                    days.forEachIndexed { i, (day, ms) ->
                        val isToday = i == days.lastIndex
                        val lim = limitOf(day)
                        val h = if (ms <= 0L) 3f else (barMax * ms / scaleMax).coerceAtLeast(6f)
                        val brush = when {
                            lim > 0 && ms > lim -> Brush.verticalGradient(listOf(Red, Color(0xFFB91C1C)))
                            isToday -> Brush.verticalGradient(listOf(Cyan, Blue))
                            else -> Brush.verticalGradient(listOf(Color(0xFF3B63C9), PastBar))
                        }
                        Box(Modifier.weight(1f).fillMaxHeight()) {
                            Column(
                                Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Bottom
                            ) {
                                if (ms >= 60_000L) {
                                    Text(hm(ms), color = if (isToday) Cyan else TextDim, fontSize = 10.sp)
                                }
                                Spacer(Modifier.height(3.dp))
                                Box(
                                    Modifier.width(22.dp).height(h.dp)
                                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                        .background(brush)
                                )
                            }
                            if (lim > 0) {
                                Box(
                                    Modifier.align(Alignment.BottomCenter)
                                        .offset(y = (-(barMax * lim / scaleMax)).dp)
                                        .width(32.dp).height(2.dp)
                                        .background(Amber)
                                )
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth()) {
                    days.forEachIndexed { i, (day, _) ->
                        Text(
                            dayLetter(day),
                            Modifier.weight(1f),
                            textAlign = TextAlign.Center,
                            color = if (i == days.lastIndex) Cyan else TextDim,
                            fontSize = 12.sp
                        )
                    }
                }
                val avg = days.sumOf { it.second } / days.size
                Text("میانگین روزانه: ${fmt(avg)}", color = TextDim, fontSize = 13.sp)
                if (days.any { limitOf(it.first) > 0 }) {
                    Text("خط زرد: سقف همون روز", color = Amber, fontSize = 12.sp)
                }
            }

            // گزارش به گوشی والدین (تلگرام یا بله)
            AppCard {
                val botEditable = Report.canEdit(ctx)
                val btn = ButtonDefaults.buttonColors(containerColor = Track, contentColor = Cyan)
                val sel = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Color.Black)
                val fieldStyle = TextStyle(color = TextMain, textDirection = TextDirection.Ltr)
                val isBale = botPlatform == "bale"
                val appName = if (isBale) "بله" else "تلگرام"

                Text("گزارش به گوشی والدین ($appName)", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { botPlatform = "telegram" }, enabled = botEditable,
                        colors = if (!isBale) sel else btn
                    ) { Text("تلگرام") }
                    Button(
                        onClick = { botPlatform = "bale" }, enabled = botEditable,
                        colors = if (isBale) sel else btn
                    ) { Text("بله") }
                }
                Text(
                    "هر روز بعد از ساعت تنظیم‌شده یک گزارش به $appName شما فرستاده می‌شه و وقتی به سقف برسه هم پیام می‌ده. " +
                        "فقط مدت استفاده و اسم برنامه‌های پرمصرف فرستاده می‌شه.",
                    color = TextDim, fontSize = 13.sp
                )
                Text(
                    "راه‌اندازی: توی $appName ربات «${if (isBale) "botfather" else "BotFather"}» رو پیدا کن و /newbot بفرست " +
                        "تا توکن بده. بعد به ربات خودت یک پیام بفرست، توکن رو اینجا بذار، «پیدا کردن شناسه» و بعد «ذخیره» رو بزن.",
                    color = TextDim, fontSize = 12.sp
                )
                if (!isBale) {
                    Text(
                        "توجه: گوشی‌ای که این برنامه روشه باید به تلگرام دسترسی داشته باشه (مثلاً وی‌پی‌ان)؛ " +
                            "وگرنه ارسال انجام نمی‌شه.",
                        color = Amber, fontSize = 12.sp
                    )
                }
                if (!botEditable) {
                    Text("بعد از ذخیره، تغییر فقط پنجشنبه‌ها از ساعت ۱۴ تا ۱۶ ممکنه.", color = Amber, fontSize = 12.sp)
                }
                OutlinedTextField(
                    value = botToken, onValueChange = { botToken = it.trim() },
                    label = { Text("توکن ربات") }, singleLine = true, enabled = botEditable,
                    textStyle = fieldStyle, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = botChat, onValueChange = { botChat = it.trim() },
                    label = { Text("شناسه‌ی چت شما") }, singleLine = true, enabled = botEditable,
                    textStyle = fieldStyle, modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("ساعت ارسال", color = TextMain, modifier = Modifier.weight(1f))
                    StepButton("−", botEditable) { reportHour = (reportHour - 1).coerceAtLeast(0) }
                    Text(
                        hm(reportHour * 3_600_000L), color = TextMain, fontSize = 16.sp,
                        textAlign = TextAlign.Center, modifier = Modifier.width(70.dp)
                    )
                    StepButton("+", botEditable) { reportHour = (reportHour + 1).coerceAtMost(23) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            scope.launch {
                                botStatus = "در حال جستجو..."
                                val (id, msg) = withContext(Dispatchers.IO) { Report.detectChatId(botPlatform, botToken) }
                                if (id != null) {
                                    botChat = id
                                    botStatus = "شناسه پیدا شد؛ حالا «ذخیره» رو بزن."
                                } else {
                                    botStatus = msg
                                }
                            }
                        },
                        enabled = botEditable && botToken.isNotBlank(),
                        colors = btn
                    ) { Text("پیدا کردن شناسه") }
                    Button(
                        onClick = {
                            botStatus = if (Report.save(ctx, botPlatform, botToken, botChat, reportHour)) "ذخیره شد."
                            else "الان امکان تغییر نیست."
                        },
                        enabled = botEditable && botToken.isNotBlank() && botChat.isNotBlank(),
                        colors = btn
                    ) { Text("ذخیره") }
                }
                Button(
                    onClick = {
                        scope.launch {
                            botStatus = "در حال ارسال..."
                            val (ok, msg) = withContext(Dispatchers.IO) { Report.sendTest(ctx) }
                            botStatus = if (ok) "✓ پیام آزمایشی فرستاده شد." else "✗ $msg"
                        }
                    },
                    enabled = Report.configured(ctx),
                    colors = btn
                ) { Text("ارسال پیام آزمایشی") }
                if (botStatus.isNotBlank()) Text(botStatus, color = TextDim, fontSize = 12.sp)
            }

            // تاریخچه‌ی روزهای قبل
            AppCard {
                Text("تاریخچه‌ی روزهای قبل", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                val todayStart = s.totals.first().first
                val past = s.history.filter { it.first < todayStart }
                if (past.isEmpty()) {
                    Text("هنوز روز قبلی ثبت نشده.", color = TextDim)
                } else {
                    Button(
                        onClick = { historyOpen = !historyOpen },
                        colors = ButtonDefaults.buttonColors(containerColor = Track, contentColor = Cyan)
                    ) { Text(if (historyOpen) "بستن" else "نمایش (${past.size} روز)") }
                    if (historyOpen) {
                        val df = SimpleDateFormat("EEEE d/M", fa)
                        past.take(60).forEach { (d, ms) ->
                            Row(Modifier.fillMaxWidth()) {
                                Text(df.format(Date(d)), color = TextMain, modifier = Modifier.weight(1f))
                                Text(fmt(ms), color = Cyan)
                            }
                        }
                    }
                }
            }

            // پشتیبان‌گیری
            if (Build.VERSION.SDK_INT >= 30) {
                AppCard {
                    Text("پشتیبان‌گیری", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    if (backupOk) {
                        Text(
                            "✓ فعاله. اطلاعات توی پوشه‌ی Documents/UsageTracker ذخیره می‌شه و اگه برنامه پاک و دوباره نصب بشه، " +
                                "بعد از دادن همین دسترسی خودش برمی‌گرده.",
                            color = Cyan, fontSize = 13.sp
                        )
                    } else {
                        Text(
                            "برای اینکه اطلاعات بعد از حذف برنامه هم بمونه، دسترسی «همه‌ی فایل‌ها» لازمه.",
                            color = Amber, fontSize = 13.sp
                        )
                        Button(
                            onClick = {
                                ctx.startActivity(
                                    Intent(
                                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                        Uri.parse("package:${ctx.packageName}")
                                    )
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)
                        ) { Text("دادن دسترسی") }
                    }
                }
            }

            // جلسه‌های امروز
            AppCard {
                Text("جلسه‌های امروز", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                if (s.sessions.isEmpty()) {
                    Text("هنوز جلسه‌ای ثبت نشده", color = TextDim)
                } else {
                    val hmFmt = SimpleDateFormat("HH:mm", fa)
                    s.sessions.asReversed().take(30).forEachIndexed { idx, (a, b) ->
                        val label = if (active && idx == 0) "${hmFmt.format(Date(a))} تا اکنون"
                        else "${hmFmt.format(Date(a))} تا ${hmFmt.format(Date(b))}"
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(label, color = TextMain, modifier = Modifier.weight(1f))
                            Text(fmt(b - a), color = Cyan)
                        }
                    }
                }
            }
        }
    }
}
