package com.example.usagetracker

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.provider.Settings
import java.util.Calendar

class UsageDb(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "usage.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "start_ms INTEGER NOT NULL, end_ms INTEGER NOT NULL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun insert(start: Long, end: Long) {
        if (end <= start) return
        writableDatabase.insert("sessions", null, ContentValues().apply {
            put("start_ms", start)
            put("end_ms", end)
        })
    }

    fun since(ms: Long): List<Pair<Long, Long>> {
        val out = ArrayList<Pair<Long, Long>>()
        readableDatabase.rawQuery(
            "SELECT start_ms, end_ms FROM sessions WHERE end_ms > ?", arrayOf(ms.toString())
        ).use { c -> while (c.moveToNext()) out.add(c.getLong(0) to c.getLong(1)) }
        return out
    }
}

object Tracker {
    @Volatile private var dbInstance: UsageDb? = null

    private fun db(c: Context): UsageDb =
        dbInstance ?: synchronized(this) {
            dbInstance ?: UsageDb(c.applicationContext).also { dbInstance = it }
        }

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences("tracker", Context.MODE_PRIVATE)

    fun openStart(c: Context): Long = sp(c).getLong("open_start", 0L)
    private fun lastSeen(c: Context): Long = sp(c).getLong("last_seen", 0L)

    /** سرویس پس‌زمینه را روشن نگه می‌دارد (چند بار صدا زدنش مشکلی ندارد). */
    fun ensureRunning(c: Context) {
        if (sp(c).getLong("setup_start", 0L) == 0L) {
            sp(c).edit().putLong("setup_start", System.currentTimeMillis()).apply()
        }
        runCatching {
            val app = c.applicationContext
            app.startForegroundService(Intent(app, TrackerService::class.java))
        }
    }

    /** شروع جلسه: وقتی قفل گوشی باز شد. */
    @Synchronized
    fun begin(c: Context) {
        if (openStart(c) == 0L) {
            val t = System.currentTimeMillis()
            sp(c).edit().putLong("open_start", t).putLong("last_seen", t).apply()
        }
    }

    /** هر ۱۵ ثانیه صدا زده می‌شود تا اگر سرویس یا گوشی ناگهانی بسته شد، زمان اضافه ثبت نشود. */
    @Synchronized
    fun beat(c: Context) {
        if (openStart(c) > 0L) {
            sp(c).edit().putLong("last_seen", System.currentTimeMillis()).apply()
        }
    }

    @Synchronized
    fun endAt(c: Context, at: Long) {
        val s = openStart(c)
        if (s > 0L) {
            if (at > s) db(c).insert(s, at)
            sp(c).edit().putLong("open_start", 0L).apply()
        }
    }

    /** پایان جلسه: وقتی صفحه خاموش شد. */
    fun end(c: Context) = endAt(c, System.currentTimeMillis())

    /** اگر جلسه‌ای باز مانده بود (سرویس مرده یا گوشی ریستارت شده)، تا آخرین زمان معتبر می‌بندد. */
    fun recover(c: Context) {
        val s = openStart(c)
        if (s > 0L) endAt(c, maxOf(s, lastSeen(c)))
    }

    private fun startOfDay(daysAgo: Int): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        add(Calendar.DAY_OF_YEAR, -daysAgo)
    }.timeInMillis

    /** جمع استفاده‌ی n روز اخیر؛ اولین عنصر امروز است. */
    /** اگر دسترسی «Usage access» داده شده باشد، از آمار سیستم (مثل Digital Wellbeing)؛ وگرنه از ثبت خود برنامه. */
    fun dailyTotals(c: Context, days: Int = 7): List<Pair<Long, Long>> =
        liveTotals(c, days).mapIndexed { i, (ds, t) ->
            History.put(c, ds, t)
            // سقف همان روز را ثبت می‌کنیم؛ برای امروز هر بار به‌روز، برای روزهای قبل فقط اگر هنوز ثبت نشده
            val dow = Calendar.getInstance().apply { timeInMillis = ds }.get(Calendar.DAY_OF_WEEK)
            if (i == 0) History.setLimit(c, ds, limitFor(c, dow))
            else History.setLimitIfAbsent(c, ds, limitFor(c, dow))
            ds to History.get(c, ds)
        }

    private fun liveTotals(c: Context, days: Int): List<Pair<Long, Long>> {
        if (!UsageSource.hasAccess(c)) return ownTotals(c, days)
        val starts = (0 until days).map { startOfDay(it) }
        return starts.mapIndexed { i, ds ->
            val total = if (i == 0) UsageSource.todayTotal(c) else UsageSource.dayTotal(c, ds, starts[i - 1])
            ds to total
        }
    }

    private fun ownTotals(c: Context, days: Int = 7): List<Pair<Long, Long>> {
        val now = System.currentTimeMillis()
        val starts = (0 until days).map { startOfDay(it) }
        val sessions = db(c).since(starts.last()).toMutableList()
        val open = openStart(c)
        if (open > 0L) sessions.add(open to now)
        return starts.mapIndexed { i, dayStart ->
            val dayEnd = if (i == 0) Long.MAX_VALUE else starts[i - 1]
            val total = sessions.sumOf { (s, e) ->
                val a = maxOf(s, dayStart)
                val b = minOf(e, dayEnd)
                if (b > a) b - a else 0L
            }
            dayStart to total
        }
    }

    /** جلسه‌های امروز (شامل جلسه‌ی در حال انجام). */
    fun todaySessions(c: Context): List<Pair<Long, Long>> {
        val dayStart = startOfDay(0)
        val list = db(c).since(dayStart).map { (s, e) -> maxOf(s, dayStart) to e }.toMutableList()
        val open = openStart(c)
        if (open > 0L) list.add(maxOf(open, dayStart) to System.currentTimeMillis())
        return list.sortedBy { it.first }
    }

    // ---------- سقف روزانه و هشدار ----------

    private fun todayDow(): Int = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)

    /** سقف یک روز هفته به دقیقه (۱=یکشنبه ... ۷=شنبه)؛ صفر یعنی بدون سقف. */
    fun limitFor(c: Context, dayOfWeek: Int): Int =
        sp(c).getInt("limit_$dayOfWeek", sp(c).getInt("limit_min", 0))

    fun allLimits(c: Context): List<Int> = (1..7).map { limitFor(c, it) }

    /** سقف امروز */
    fun dailyLimitMin(c: Context): Int = limitFor(c, todayDow())

    fun setLimitFor(c: Context, dayOfWeek: Int, minutes: Int): Boolean {
        if (!canEditSettings(c)) return false
        val e = sp(c).edit().putInt("limit_$dayOfWeek", minutes)
        // با تغییر سقف امروز، هشدار امروز دوباره فعال می‌شود
        if (dayOfWeek == todayDow()) e.putLong("alerted_day", 0L)
        e.apply()
        Backup.write(c)
        return true
    }

    /** برای بازیابی از پشتیبان (قفل پنجشنبه اینجا اعمال نمی‌شود). */
    fun restoreLimit(c: Context, dayOfWeek: Int, minutes: Int) {
        sp(c).edit().putInt("limit_$dayOfWeek", minutes).apply()
    }

    fun setupStart(c: Context): Long = sp(c).getLong("setup_start", 0L)

    fun restoreSetup(c: Context, v: Long) {
        if (v <= 0L) return
        val cur = setupStart(c)
        if (cur == 0L || v < cur) sp(c).edit().putLong("setup_start", v).apply()
    }

    fun todayTotal(c: Context): Long = dailyTotals(c, 1).first().second

    /** اگر امروز به سقف رسیده و هنوز هشداری داده نشده، true برمی‌گرداند (و یک بار ثبت می‌کند). */
    @Synchronized
    fun shouldAlert(c: Context): Boolean {
        val limit = dailyLimitMin(c)
        if (limit <= 0) return false
        val day = startOfDay(0)
        if (sp(c).getLong("alerted_day", 0L) == day) return false
        if (todayTotal(c) < limit * 60_000L) return false
        sp(c).edit().putLong("alerted_day", day).apply()
        return true
    }

    // ---------- قفل تنظیمات: فقط پنجشنبه ۱۴ تا ۱۶ ----------

    private fun autoTimeOn(c: Context): Boolean =
        Settings.Global.getInt(c.contentResolver, Settings.Global.AUTO_TIME, 1) == 1

    /**
     * تغییر سقف و برنامه‌های مجاز فقط در این حالت‌ها ممکن است:
     *  - پنجشنبه از ساعت ۱۴ تا ۱۶
     *  - یک ساعت اول بعد از اولین بازکردن این نسخه (برای راه‌اندازی و تست)
     * و در هر دو حالت، تاریخ و ساعت گوشی باید خودکار باشد (تا با دستکاری ساعت دور زده نشود).
     */
    fun canEditSettings(c: Context): Boolean {
        if (!autoTimeOn(c)) return false
        val now = System.currentTimeMillis()
        val setup = sp(c).getLong("setup_start", 0L)
        if (setup > 0L && now >= setup && now - setup < 60 * 60 * 1000L) return true
        val cal = Calendar.getInstance()
        return cal.get(Calendar.DAY_OF_WEEK) == Calendar.THURSDAY &&
            cal.get(Calendar.HOUR_OF_DAY) in 14..15
    }

    // ---------- درخت پاییزی ----------

    private fun nextDayStart(dayStart: Long): Long =
        Calendar.getInstance().apply { timeInMillis = dayStart; add(Calendar.DAY_OF_YEAR, 1) }.timeInMillis

    /** نتیجه‌ی یک روز تمام‌شده: ۱ = زیر سقف (برگ)، ۰ = از سقف گذشته، ‎-۱ = سقفی تعیین نشده بود. */
    fun dayResult(c: Context, dayStart: Long, total: Long): Int {
        val dow = Calendar.getInstance().apply { timeInMillis = dayStart }.get(Calendar.DAY_OF_WEEK)
        val lim = History.limitFor(c, dayStart) ?: limitFor(c, dow)
        if (lim <= 0) return -1
        return if (total <= lim * 60_000L) 1 else 0
    }

    /** تعداد برگ‌ها (روزهای تمام‌شده‌ی زیر سقف)، روزهای پشت سر هم تا دیروز، و بهترین دوره. امروز بعد از تمام شدن روز حساب می‌شود. */
    fun treeStats(c: Context): TreeStats {
        val todayStart = startOfDay(0)
        val days = History.list(c).filter { it.first < todayStart }.sortedBy { it.first }
        var leaves = 0
        var run = 0
        var best = 0
        var prev = 0L
        for ((d, t) in days) {
            if (dayResult(c, d, t) == 1) {
                run = if (prev != 0L && run > 0 && nextDayStart(prev) == d) run + 1 else 1
                leaves++
                if (run > best) best = run
            } else {
                run = 0
            }
            prev = d
        }
        val streak = if (prev == startOfDay(1)) run else 0
        return TreeStats(leaves, streak, best)
    }
}

data class TreeStats(val leaves: Int, val streak: Int, val best: Int)
