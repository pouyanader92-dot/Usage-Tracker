package com.example.usagetracker

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import java.util.Calendar

/**
 * آمار استفاده از خود سیستم اندروید (همان منبعی که Digital Wellbeing استفاده می‌کند).
 * نیاز به دسترسی «Usage access» دارد.
 */
object UsageSource {

    @Suppress("DEPRECATION")
    fun hasAccess(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        } else {
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** مدت جلوی‌صفحه بودن هر برنامه بین from و to (میلی‌ثانیه). */
    @Suppress("DEPRECATION")
    fun perApp(c: Context, from: Long, to: Long): Map<String, Long> {
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return emptyMap()
        // کمی عقب‌تر شروع می‌کنیم تا برنامه‌ای که از قبل از شروع بازه باز بوده هم شمرده شود
        val events = usm.queryEvents(from - 2 * 3600_000L, to) ?: return emptyMap()

        val pm = c.packageManager
        val home = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        ).map { it.activityInfo.packageName }.toSet()
        val counted = HashMap<String, Boolean>()
        fun counts(pkg: String): Boolean = counted.getOrPut(pkg) {
            pkg !in home && pm.getLaunchIntentForPackage(pkg) != null
        }

        val result = HashMap<String, Long>()
        val e = UsageEvents.Event()
        var cur: String? = null
        var curStart = 0L

        fun close(at: Long) {
            val p = cur
            if (p != null) {
                val s = maxOf(curStart, from)
                val en = minOf(at, to)
                if (en > s && counts(p)) result[p] = (result[p] ?: 0L) + (en - s)
            }
            cur = null
        }

        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> {
                    if (cur != e.packageName) {
                        close(e.timeStamp)
                        cur = e.packageName
                        curStart = e.timeStamp
                    }
                }
                UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                    if (cur == e.packageName) close(e.timeStamp)
                }
                UsageEvents.Event.SCREEN_NON_INTERACTIVE,
                UsageEvents.Event.KEYGUARD_SHOWN -> close(e.timeStamp)
                else -> {}
            }
        }
        close(to)
        return result
    }

    private fun startOfToday(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    // ---- کش: امروز هر ۵ ثانیه، روزهای گذشته فقط یک بار ----
    @Volatile private var todayAt = 0L
    @Volatile private var todayDay = 0L
    @Volatile private var todayMap: Map<String, Long> = emptyMap()
    private val past = HashMap<Long, Long>()

    fun todayPerApp(c: Context): Map<String, Long> {
        val now = System.currentTimeMillis()
        val day = startOfToday()
        if (todayDay == day && now - todayAt < 5_000L) return todayMap
        val m = perApp(c, day, now)
        todayMap = m; todayAt = now; todayDay = day
        return m
    }

    fun todayTotal(c: Context): Long = todayPerApp(c).values.sum()

    fun dayTotal(c: Context, dayStart: Long, dayEnd: Long): Long {
        synchronized(past) { past[dayStart]?.let { return it } }
        val t = perApp(c, dayStart, dayEnd).values.sum()
        synchronized(past) { past[dayStart] = t }
        return t
    }
}
