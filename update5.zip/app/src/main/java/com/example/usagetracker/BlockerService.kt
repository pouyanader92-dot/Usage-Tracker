package com.example.usagetracker

// قابلیت بستن برنامه‌ها بعد از سقف حذف شد؛ این فایل عمداً خالی است.
