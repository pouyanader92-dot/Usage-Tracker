plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// توکن ربات و شناسه‌ی چت مربی از Secretهای گیت‌هاب موقع بیلد می‌آیند (توی سورس نوشته نمی‌شوند)
val botToken = (System.getenv("BOT_TOKEN") ?: "").trim().replace("\"", "")
val coachChat = (System.getenv("COACH_CHAT_ID") ?: "").trim().replace("\"", "")

android {
    namespace = "com.example.usagetracker"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.usagetracker"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "BOT_TOKEN", "\"$botToken\"")
        buildConfigField("String", "COACH_CHAT", "\"$coachChat\"")
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
}
