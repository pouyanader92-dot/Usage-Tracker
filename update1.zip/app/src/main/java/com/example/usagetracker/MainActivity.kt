package com.example.usagetracker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Tracker.ensureRunning(this)   // ثبت خودکار، بدون سوییچ
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(
                    colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Navy)
                ) { Screen() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Tracker.ensureRunning(this)
    }
}

private val Navy = Color(0xFF050B1F)
private val NavyLight = Color(0xFF0A1A4A)
private val CardBg = Color(0xFF0E1B3D)
private val CardBorder = Color(0xFF1B2F6B)
private val Track = Color(0xFF16254F)
private val Cyan = Color(0xFF22D3EE)
private val Blue = Color(0xFF2563EB)
private val TextMain = Color(0xFFE6EEFF)
private val TextDim = Color(0xFF8FA3CC)
private val Amber = Color(0xFFFBBF24)

private val fa = Locale("fa")

private fun fmt(ms: Long): String {
    val nf = NumberFormat.getInstance(fa)
    val m = ms / 60000
    val h = m / 60
    val mm = m % 60
    return when {
        m == 0L -> if (ms > 0) "کمتر از یک دقیقه" else "۰ دقیقه"
        h == 0L -> "${nf.format(mm)} دقیقه"
        else -> "${nf.format(h)} ساعت و ${nf.format(mm)} دقیقه"
    }
}

private fun clock(ms: Long): String {
    val nf = NumberFormat.getInstance(fa).apply { minimumIntegerDigits = 2; isGroupingUsed = false }
    val t = maxOf(ms, 0L) / 1000
    return "${nf.format(t / 3600)}:${nf.format(t % 3600 / 60)}:${nf.format(t % 60)}"
}

private data class Snap(
    val totals: List<Pair<Long, Long>>,
    val sessions: List<Pair<Long, Long>>,
    val openStart: Long
)

@Composable
private fun AppCard(content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.fillMaxWidth()
            .clip(shape)
            .background(CardBg)
            .border(1.dp, CardBorder, shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
private fun Screen() {
    val ctx = LocalContext.current
    var snap by remember { mutableStateOf<Snap?>(null) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var batteryOk by remember { mutableStateOf(true) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    LaunchedEffect(Unit) {
        while (true) {
            snap = withContext(Dispatchers.IO) {
                Snap(Tracker.dailyTotals(ctx), Tracker.todaySessions(ctx), Tracker.openStart(ctx))
            }
            now = System.currentTimeMillis()
            batteryOk = ctx.getSystemService(PowerManager::class.java)
                .isIgnoringBatteryOptimizations(ctx.packageName)
            delay(1000)
        }
    }

    val s = snap
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Navy, NavyLight)))) {
        if (s == null) return@Box
        Column(
            Modifier.fillMaxSize().statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // سربرگ
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.logo), contentDescription = null, modifier = Modifier.size(46.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("UsageTracker", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("ثبت زمان استفاده از گوشی", color = TextDim, fontSize = 13.sp)
                }
            }

            // هشدار باتری
            if (!batteryOk) {
                AppCard {
                    Text("برای کار در پس‌زمینه، محدودیت باتری باید برداشته بشه.", color = Amber)
                    Button(
                        onClick = {
                            ctx.startActivity(
                                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                                    .setData(Uri.parse("package:${ctx.packageName}"))
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)
                    ) { Text("اجازه دادن") }
                }
            }

            // جلسه‌ی فعلی
            val active = s.openStart > 0L
            Box(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(Blue, Cyan)))
                    .padding(20.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        if (active) "جلسه‌ی فعلی (از باز شدن قفل)" else "گوشی الان قفل یا خاموش است",
                        color = Color.White, fontSize = 14.sp
                    )
                    if (active) {
                        Text(clock(now - s.openStart), color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // مجموع امروز
            AppCard {
                Text("مجموع امروز", color = TextDim, fontSize = 14.sp)
                Text(fmt(s.totals.first().second), color = Cyan, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }

            // جلسه‌های امروز
            AppCard {
                Text("جلسه‌های امروز", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                if (s.sessions.isEmpty()) {
                    Text("هنوز جلسه‌ای ثبت نشده", color = TextDim)
                } else {
                    val hm = SimpleDateFormat("HH:mm", fa)
                    s.sessions.asReversed().take(30).forEachIndexed { idx, (a, b) ->
                        val label = if (active && idx == 0) "${hm.format(Date(a))} تا اکنون"
                        else "${hm.format(Date(a))} تا ${hm.format(Date(b))}"
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(label, color = TextMain, modifier = Modifier.weight(1f))
                            Text(fmt(b - a), color = Cyan)
                        }
                    }
                }
            }

            // ۷ روز اخیر
            AppCard {
                Text("۷ روز اخیر", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                val dayFmt = SimpleDateFormat("EEEE d/M", fa)
                val max = s.totals.maxOf { it.second }.coerceAtLeast(1L)
                s.totals.forEach { (day, ms) ->
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(Modifier.fillMaxWidth()) {
                            Text(dayFmt.format(Date(day)), color = TextMain, modifier = Modifier.weight(1f))
                            Text(fmt(ms), color = TextDim)
                        }
                        Box(
                            Modifier.fillMaxWidth().height(6.dp)
                                .clip(RoundedCornerShape(3.dp)).background(Track)
                        ) {
                            if (ms > 0) {
                                Box(
                                    Modifier.fillMaxWidth((ms.toFloat() / max).coerceIn(0.03f, 1f))
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(Brush.horizontalGradient(listOf(Blue, Cyan)))
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
