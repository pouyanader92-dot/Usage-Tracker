package com.example.usagetracker

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * بعد از رسیدن به سقف روزانه، اگر برنامه‌ی باز‌شده مجاز نباشد، به صفحه‌ی اصلی برمی‌گرداند.
 * فقط نام برنامه‌ی جلوی صفحه را می‌بیند و محتوای صفحه را نمی‌خواند.
 */
class BlockerService : AccessibilityService() {

    private var lastToast = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (!Tracker.isOverLimit(this)) return
        if (!Tracker.shouldBlock(this, pkg)) return

        performGlobalAction(GLOBAL_ACTION_HOME)

        val t = System.currentTimeMillis()
        if (t - lastToast > 3000) {
            lastToast = t
            Toast.makeText(
                this, "سقف امروز تموم شده؛ فقط تماس و برنامه‌های مجاز باز می‌شن", Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onInterrupt() {}
}
