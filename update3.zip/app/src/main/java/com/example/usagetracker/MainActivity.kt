package com.example.usagetracker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Tracker.ensureRunning(this)   // ثبت خودکار، بدون سوییچ
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(
                    colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Navy)
                ) { Screen() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Tracker.ensureRunning(this)
    }
}

private val Navy = Color(0xFF050B1F)
private val NavyLight = Color(0xFF0A1A4A)
private val CardBg = Color(0xFF0E1B3D)
private val CardBorder = Color(0xFF1B2F6B)
private val Track = Color(0xFF16254F)
private val Cyan = Color(0xFF22D3EE)
private val Blue = Color(0xFF2563EB)
private val PastBar = Color(0xFF2B4FA8)
private val TextMain = Color(0xFFE6EEFF)
private val TextDim = Color(0xFF8FA3CC)
private val Amber = Color(0xFFFBBF24)
private val Red = Color(0xFFF87171)

private val fa = Locale("fa")

private fun fmt(ms: Long): String {
    val nf = NumberFormat.getInstance(fa)
    val m = ms / 60000
    val h = m / 60
    val mm = m % 60
    return when {
        m == 0L -> if (ms > 0) "کمتر از یک دقیقه" else "۰ دقیقه"
        h == 0L -> "${nf.format(mm)} دقیقه"
        else -> "${nf.format(h)} ساعت و ${nf.format(mm)} دقیقه"
    }
}

private fun clock(ms: Long): String {
    val nf = NumberFormat.getInstance(fa).apply { minimumIntegerDigits = 2; isGroupingUsed = false }
    val t = maxOf(ms, 0L) / 1000
    return "${nf.format(t / 3600)}:${nf.format(t % 3600 / 60)}:${nf.format(t % 60)}"
}

/** ساعت:دقیقه، مثل ۲:۱۵ */
private fun hm(ms: Long): String {
    val nh = NumberFormat.getInstance(fa).apply { isGroupingUsed = false }
    val nm = NumberFormat.getInstance(fa).apply { minimumIntegerDigits = 2; isGroupingUsed = false }
    val m = ms / 60000
    return "${nh.format(m / 60)}:${nm.format(m % 60)}"
}

private fun dayLetter(ms: Long): String {
    val d = Calendar.getInstance().apply { timeInMillis = ms }.get(Calendar.DAY_OF_WEEK)
    return when (d) {
        Calendar.SATURDAY -> "ش"
        Calendar.SUNDAY -> "ی"
        Calendar.MONDAY -> "د"
        Calendar.TUESDAY -> "س"
        Calendar.WEDNESDAY -> "چ"
        Calendar.THURSDAY -> "پ"
        else -> "ج"
    }
}

private data class Snap(
    val totals: List<Pair<Long, Long>>,
    val sessions: List<Pair<Long, Long>>,
    val openStart: Long
)

@Composable
private fun AppCard(content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.fillMaxWidth()
            .clip(shape)
            .background(CardBg)
            .border(1.dp, CardBorder, shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
private fun Ring(
    progress: Float,
    color: Color,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 14.dp.toPx()
            val tl = Offset(stroke / 2, stroke / 2)
            val sz = Size(size.width - stroke, size.height - stroke)
            drawArc(
                color = Track, startAngle = -90f, sweepAngle = 360f, useCenter = false,
                topLeft = tl, size = sz, style = Stroke(width = stroke)
            )
            if (progress > 0f) {
                drawArc(
                    color = color, startAngle = -90f, sweepAngle = 360f * progress, useCenter = false,
                    topLeft = tl, size = sz, style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, content = content)
    }
}

@Composable
private fun StepButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Track, contentColor = Cyan,
            disabledContainerColor = Track.copy(alpha = 0.5f), disabledContentColor = TextDim
        )
    ) { Text(label, fontSize = 20.sp) }
}

@Composable
private fun Screen() {
    val ctx = LocalContext.current
    var snap by remember { mutableStateOf<Snap?>(null) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var batteryOk by remember { mutableStateOf(true) }
    var limit by remember { mutableStateOf(Tracker.dailyLimitMin(ctx)) }
    var editable by remember { mutableStateOf(Tracker.canEditSettings(ctx)) }
    var blockerOn by remember { mutableStateOf(Tracker.isBlockerEnabled(ctx)) }
    var allowed by remember { mutableStateOf(Tracker.allowedApps(ctx)) }
    var expanded by remember { mutableStateOf(false) }
    val apps = remember { Tracker.launchableApps(ctx) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    LaunchedEffect(Unit) {
        while (true) {
            snap = withContext(Dispatchers.IO) {
                Snap(Tracker.dailyTotals(ctx), Tracker.todaySessions(ctx), Tracker.openStart(ctx))
            }
            now = System.currentTimeMillis()
            batteryOk = ctx.getSystemService(PowerManager::class.java)
                .isIgnoringBatteryOptimizations(ctx.packageName)
            editable = Tracker.canEditSettings(ctx)
            blockerOn = Tracker.isBlockerEnabled(ctx)
            delay(1000)
        }
    }

    val s = snap
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Navy, NavyLight)))) {
        if (s == null) return@Box
        val active = s.openStart > 0L
        val total = s.totals.first().second
        val limitMs = limit * 60_000L
        val over = limitMs > 0 && total >= limitMs
        val progress = if (limitMs > 0) (total.toFloat() / limitMs).coerceIn(0f, 1f) else 0f
        val ringColor = when {
            over -> Red
            progress >= 0.8f -> Amber
            else -> Cyan
        }

        Column(
            Modifier.fillMaxSize().statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // سربرگ
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.logo), contentDescription = null, modifier = Modifier.size(46.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("UsageTracker", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("ثبت زمان استفاده از گوشی", color = TextDim, fontSize = 13.sp)
                }
            }

            // هشدار باتری
            if (!batteryOk) {
                AppCard {
                    Text("برای کار در پس‌زمینه، محدودیت باتری باید برداشته بشه.", color = Amber)
                    Button(
                        onClick = {
                            ctx.startActivity(
                                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                                    .setData(Uri.parse("package:${ctx.packageName}"))
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)
                    ) { Text("اجازه دادن") }
                }
            }

            // کارت اصلی: حلقه‌ی پیشرفت + جلسه‌ی فعلی
            AppCard {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Ring(progress, ringColor, Modifier.size(150.dp)) {
                        Text(hm(total), color = TextMain, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text("امروز", color = TextDim, fontSize = 12.sp)
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(if (active) "جلسه‌ی فعلی" else "گوشی قفل است", color = TextDim, fontSize = 13.sp)
                        if (active) {
                            Text(clock(now - s.openStart), color = Cyan, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        }
                        if (limitMs > 0) {
                            if (over) {
                                Text("از سقف گذشته: ${fmt(total - limitMs)}", color = Red, fontSize = 14.sp)
                            } else {
                                Text("مانده تا سقف: ${fmt(limitMs - total)}", color = TextMain, fontSize = 14.sp)
                            }
                        } else {
                            Text("سقف روزانه تعیین نشده", color = TextDim, fontSize = 13.sp)
                        }
                    }
                }
            }

            // سقف روزانه
            AppCard {
                Text("سقف استفاده‌ی روزانه", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StepButton("−", editable) {
                        val n = (limit - 15).coerceAtLeast(0)
                        if (Tracker.setDailyLimitMin(ctx, n)) limit = n
                    }
                    Text(
                        if (limit == 0) "بدون سقف" else fmt(limitMs),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold
                    )
                    StepButton("+", editable) {
                        val n = (limit + 15).coerceAtMost(720)
                        if (Tracker.setDailyLimitMin(ctx, n)) limit = n
                    }
                }
                if (editable) {
                    Text("الان می‌تونی سقف و برنامه‌های مجاز رو تغییر بدی.", color = Cyan, fontSize = 12.sp)
                } else {
                    Text(
                        "تغییر سقف و برنامه‌های مجاز فقط پنجشنبه‌ها از ساعت ۱۴ تا ۱۶ ممکنه " +
                            "(تاریخ و ساعت گوشی باید روی «خودکار» باشه).",
                        color = Amber, fontSize = 12.sp
                    )
                }
                Text("وقتی زمان امروز به سقف برسه، هشدار نشون داده می‌شه.", color = TextDim, fontSize = 12.sp)
            }

            // محدودیت بعد از سقف
            AppCard {
                Text("بعد از رسیدن به سقف", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(
                    "فقط تماس و برنامه‌های مجاز (مثل بله) باز می‌شن؛ بقیه‌ی برنامه‌ها بسته می‌شن.",
                    color = TextDim, fontSize = 13.sp
                )
                if (blockerOn) {
                    Text("✓ سرویس محدودیت فعاله", color = Cyan)
                } else {
                    Text("سرویس محدودیت خاموشه؛ بدون اون برنامه‌ها بسته نمی‌شن.", color = Amber, fontSize = 13.sp)
                    Button(
                        onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                        colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color.Black)
                    ) { Text("فعال‌سازی در تنظیمات دسترسی‌پذیری") }
                    Text(
                        "اگه اندروید پیام «Restricted setting» داد: «تنظیمات برنامه» ← سه‌نقطه ← " +
                            "Allow restricted settings رو بزن و دوباره فعال کن.",
                        color = TextDim, fontSize = 12.sp
                    )
                    Button(
                        onClick = {
                            ctx.startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                    .setData(Uri.parse("package:${ctx.packageName}"))
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Track, contentColor = Cyan)
                    ) { Text("تنظیمات برنامه") }
                }
            }

            // برنامه‌های مجاز
            AppCard {
                Text("برنامه‌های مجاز بعد از سقف", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                val names = apps.filter { it.first in allowed }.map { it.second }
                Text(
                    "تماس (همیشه مجاز)" + names.joinToString("") { "، $it" },
                    color = TextDim, fontSize = 13.sp
                )
                Button(
                    onClick = { expanded = !expanded },
                    colors = ButtonDefaults.buttonColors(containerColor = Track, contentColor = Cyan)
                ) { Text(if (expanded) "بستن لیست" else "نمایش لیست برنامه‌ها") }
                if (expanded) {
                    if (!editable) {
                        Text("ویرایش فقط پنجشنبه‌ها ۱۴ تا ۱۶ ممکنه.", color = Amber, fontSize = 12.sp)
                    }
                    apps.forEach { (pkg, label) ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = pkg in allowed,
                                enabled = editable,
                                onCheckedChange = { on ->
                                    val n = if (on) allowed + pkg else allowed - pkg
                                    if (Tracker.setAllowedApps(ctx, n)) allowed = n
                                },
                                colors = CheckboxDefaults.colors(checkedColor = Cyan)
                            )
                            Text(label, color = TextMain)
                        }
                    }
                }
            }

            // نمودار هفتگی
            AppCard {
                Text("۷ روز اخیر", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                val days = s.totals.asReversed()          // قدیمی‌ترین راست، امروز چپ
                val scaleMax = maxOf(days.maxOf { it.second }, limitMs).coerceAtLeast(60_000L)
                val barMax = 100f

                Box(Modifier.fillMaxWidth().height(130.dp)) {
                    if (limitMs > 0) {
                        Box(
                            Modifier.fillMaxWidth().height(1.dp)
                                .align(Alignment.BottomStart)
                                .offset(y = (-(barMax * limitMs / scaleMax)).dp)
                                .background(Amber.copy(alpha = 0.8f))
                        )
                    }
                    Row(Modifier.fillMaxSize()) {
                        days.forEachIndexed { i, (_, ms) ->
                            val isToday = i == days.lastIndex
                            val h = if (ms <= 0L) 3f else (barMax * ms / scaleMax).coerceAtLeast(6f)
                            val brush = when {
                                limitMs > 0 && ms > limitMs -> Brush.verticalGradient(listOf(Red, Color(0xFFB91C1C)))
                                isToday -> Brush.verticalGradient(listOf(Cyan, Blue))
                                else -> Brush.verticalGradient(listOf(Color(0xFF3B63C9), PastBar))
                            }
                            Column(
                                Modifier.weight(1f).fillMaxHeight(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Bottom
                            ) {
                                if (ms >= 60_000L) {
                                    Text(hm(ms), color = if (isToday) Cyan else TextDim, fontSize = 10.sp)
                                }
                                Spacer(Modifier.height(3.dp))
                                Box(
                                    Modifier.width(22.dp).height(h.dp)
                                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                        .background(brush)
                                )
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth()) {
                    days.forEachIndexed { i, (day, _) ->
                        Text(
                            dayLetter(day),
                            Modifier.weight(1f),
                            textAlign = TextAlign.Center,
                            color = if (i == days.lastIndex) Cyan else TextDim,
                            fontSize = 12.sp
                        )
                    }
                }
                val avg = days.sumOf { it.second } / days.size
                Text("میانگین روزانه: ${fmt(avg)}", color = TextDim, fontSize = 13.sp)
                if (limitMs > 0) Text("خط زرد: سقف روزانه", color = Amber, fontSize = 12.sp)
            }

            // جلسه‌های امروز
            AppCard {
                Text("جلسه‌های امروز", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                if (s.sessions.isEmpty()) {
                    Text("هنوز جلسه‌ای ثبت نشده", color = TextDim)
                } else {
                    val hmFmt = SimpleDateFormat("HH:mm", fa)
                    s.sessions.asReversed().take(30).forEachIndexed { idx, (a, b) ->
                        val label = if (active && idx == 0) "${hmFmt.format(Date(a))} تا اکنون"
                        else "${hmFmt.format(Date(a))} تا ${hmFmt.format(Date(b))}"
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(label, color = TextMain, modifier = Modifier.weight(1f))
                            Text(fmt(b - a), color = Cyan)
                        }
                    }
                }
            }
        }
    }
}
