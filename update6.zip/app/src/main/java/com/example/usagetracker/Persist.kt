package com.example.usagetracker

import android.content.Context
import android.os.Build
import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** تاریخچه‌ی مدت استفاده‌ی هر روز (تاریخ ← میلی‌ثانیه)؛ مقدار هر روز فقط بیشتر می‌شود. */
object History {
    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences("history", Context.MODE_PRIVATE)

    private fun fmt() = SimpleDateFormat("yyyyMMdd", Locale.US)

    fun keyOf(dayStart: Long): String = fmt().format(Date(dayStart))

    fun put(c: Context, dayStart: Long, total: Long) = putKey(c, keyOf(dayStart), total)

    @Synchronized
    fun putKey(c: Context, key: String, total: Long) {
        if (total <= 0L) return
        if (total > sp(c).getLong(key, 0L)) sp(c).edit().putLong(key, total).apply()
    }

    fun get(c: Context, dayStart: Long): Long = sp(c).getLong(keyOf(dayStart), 0L)

    fun all(c: Context): Map<String, Long> {
        val out = HashMap<String, Long>()
        for ((k, v) in sp(c).all) if (v is Long) out[k] = v
        return out
    }

    /** همه‌ی روزها (شروع روز ← مدت)، جدیدترین اول. */
    fun list(c: Context): List<Pair<Long, Long>> {
        val f = fmt()
        return all(c).mapNotNull { (k, v) ->
            val d = runCatching { f.parse(k)?.time }.getOrNull() ?: return@mapNotNull null
            d to v
        }.sortedByDescending { it.first }
    }
}

/**
 * پشتیبان‌گیری در فایل Documents/UsageTracker/backup.json (نیاز به دسترسی «همه‌ی فایل‌ها»).
 * فایل بعد از حذف برنامه می‌ماند و بعد از نصب دوباره خودکار برمی‌گردد.
 * فایل امضا دارد تا با ویرایش دستی قابل جعل نباشد.
 */
object Backup {
    private const val SALT = "ut-8f3a1c9e72b4-2026"
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var lastTick = 0L

    private fun file() = File(Environment.getExternalStorageDirectory(), "Documents/UsageTracker/backup.json")

    fun hasPermission(): Boolean = Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("backup", Context.MODE_PRIVATE)

    private fun sig(payload: String): String =
        MessageDigest.getInstance("SHA-256").digest((payload + SALT).toByteArray())
            .joinToString("") { "%02x".format(it) }

    @Synchronized
    fun write(c: Context) {
        if (!hasPermission() || !sp(c).getBoolean("restore_done", false)) return
        runCatching {
            val limits = JSONArray()
            for (d in 1..7) limits.put(Tracker.limitFor(c, d))
            val hist = JSONObject()
            for ((k, v) in History.all(c)) hist.put(k, v)
            val payload = JSONObject()
                .put("limits", limits)
                .put("history", hist)
                .put("setup", Tracker.setupStart(c))
                .put("saved", System.currentTimeMillis())
                .toString()
            val out = JSONObject().put("payload", payload).put("sig", sig(payload)).toString()
            val f = file()
            f.parentFile?.mkdirs()
            f.writeText(out)
        }
    }

    /** یک بار بعد از گرفتن دسترسی: اگر پشتیبان معتبر هست برمی‌گردد. */
    @Synchronized
    fun restoreIfNeeded(c: Context) {
        if (!hasPermission()) return
        if (sp(c).getBoolean("restore_done", false)) return
        val f = file()
        if (f.exists()) {
            val ok = runCatching {
                val root = JSONObject(f.readText())
                val payload = root.getString("payload")
                if (root.getString("sig") != sig(payload)) error("bad signature")
                val p = JSONObject(payload)
                val limits = p.getJSONArray("limits")
                for (i in 0 until minOf(7, limits.length())) Tracker.restoreLimit(c, i + 1, limits.getInt(i))
                val h = p.getJSONObject("history")
                for (k in h.keys()) History.putKey(c, k, h.getLong(k))
                Tracker.restoreSetup(c, p.optLong("setup", 0L))
            }.isSuccess
            // فایل خراب یا دست‌کاری‌شده را کنار می‌گذاریم تا رویش نوشته نشود
            if (!ok) runCatching { f.renameTo(File(f.parentFile, "backup.bad.json")) }
        }
        sp(c).edit().putBoolean("restore_done", true).apply()
        write(c)
    }

    /** هر حدود یک دقیقه از سرویس صدا زده می‌شود (روی رشته‌ی پس‌زمینه). */
    fun tick(c: Context) {
        val now = System.currentTimeMillis()
        if (now - lastTick < 60_000L) return
        lastTick = now
        val app = c.applicationContext
        exec.execute {
            runCatching {
                Tracker.dailyTotals(app, 2)   // تاریخچه‌ی امروز و دیروز به‌روز می‌شود
                restoreIfNeeded(app)
                write(app)
            }
        }
    }
}
