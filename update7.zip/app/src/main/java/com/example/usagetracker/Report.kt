package com.example.usagetracker

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * گزارش روزانه و پیام رسیدن به سقف، از طریق ربات بله (tapi.bale.ai).
 * توکن و شناسه‌ی چت فقط روی همین گوشی ذخیره می‌شوند و داخل فایل پشتیبان نمی‌روند.
 */
object Report {
    private const val API = "https://tapi.bale.ai/bot"
    private val fa = Locale("fa")
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var lastCheck = 0L

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences("report", Context.MODE_PRIVATE)

    fun token(c: Context): String = sp(c).getString("token", "") ?: ""
    fun chatId(c: Context): String = sp(c).getString("chat", "") ?: ""
    fun hour(c: Context): Int = sp(c).getInt("hour", 21)
    fun lastStatus(c: Context): String = sp(c).getString("status", "") ?: ""

    fun configured(c: Context): Boolean = token(c).isNotBlank() && chatId(c).isNotBlank()

    /** بار اول آزاد است؛ بعد از ذخیره، تغییر فقط در بازه‌ی پنجشنبه (مثل سقف‌ها). */
    fun canEdit(c: Context): Boolean = !configured(c) || Tracker.canEditSettings(c)

    fun save(c: Context, token: String, chat: String, hour: Int): Boolean {
        if (!canEdit(c)) return false
        sp(c).edit()
            .putString("token", token.trim())
            .putString("chat", chat.trim())
            .putInt("hour", hour.coerceIn(0, 23))
            .apply()
        return true
    }

    private fun setStatus(c: Context, ok: Boolean, msg: String) {
        val t = SimpleDateFormat("HH:mm", fa).format(Date())
        sp(c).edit().putString("status", (if (ok) "✓ " else "✗ ") + msg + " (" + t + ")").apply()
    }

    private fun dur(ms: Long): String {
        val nf = NumberFormat.getInstance(fa)
        val m = ms / 60000
        val h = m / 60
        val mm = m % 60
        return when {
            m == 0L -> if (ms > 0) "کمتر از یک دقیقه" else "۰ دقیقه"
            h == 0L -> "${nf.format(mm)} دقیقه"
            else -> "${nf.format(h)} ساعت و ${nf.format(mm)} دقیقه"
        }
    }

    // ---------- شبکه ----------

    private fun call(token: String, method: String, body: JSONObject?): Pair<Boolean, String> {
        var conn: HttpURLConnection? = null
        return try {
            val k = URL("$API$token/$method").openConnection() as HttpURLConnection
            conn = k
            k.requestMethod = "POST"
            k.connectTimeout = 15_000
            k.readTimeout = 20_000
            k.doOutput = true
            k.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            k.outputStream.use { it.write((body ?: JSONObject()).toString().toByteArray(Charsets.UTF_8)) }
            val code = k.responseCode
            val stream = if (code in 200..299) k.inputStream else k.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code in 200..299) true to text else false to "خطا $code (توکن یا شناسه رو چک کن)"
        } catch (e: Exception) {
            false to "اتصال برقرار نشد"
        } finally {
            conn?.disconnect()
        }
    }

    /** فرستادن متن به چت ذخیره‌شده. باید روی رشته‌ی پس‌زمینه صدا زده شود. */
    fun sendNow(c: Context, text: String): Pair<Boolean, String> {
        val tk = token(c)
        val chat = chatId(c)
        if (tk.isBlank() || chat.isBlank()) return false to "هنوز تنظیم نشده"
        val body = JSONObject().put("chat_id", chat.toLongOrNull() ?: chat).put("text", text)
        val r = call(tk, "sendMessage", body)
        setStatus(c, r.first, if (r.first) "ارسال شد" else r.second)
        return r
    }

    fun sendTest(c: Context): Pair<Boolean, String> =
        sendNow(c, "✅ پیام آزمایشی UsageTracker: ارتباط با ربات برقراره.")

    /** آخرین پیامی که به ربات داده شده را می‌خواند و شناسه‌ی چت را برمی‌گرداند. */
    fun detectChatId(token: String): Pair<String?, String> {
        if (token.isBlank()) return null to "اول توکن رو وارد کن"
        val r = call(token.trim(), "getUpdates", null)
        if (!r.first) return null to r.second
        try {
            val arr = JSONObject(r.second).getJSONArray("result")
            for (i in arr.length() - 1 downTo 0) {
                val msg = arr.getJSONObject(i).optJSONObject("message")
                if (msg != null) return msg.getJSONObject("chat").get("id").toString() to "ok"
            }
        } catch (e: Exception) {
            return null to "جواب بله قابل خوندن نبود"
        }
        return null to "هنوز پیامی به ربات نرسیده؛ توی بله به ربات یک پیام بفرست و دوباره امتحان کن."
    }

    // ---------- متن گزارش ----------

    private fun buildReport(c: Context): String {
        val (dayStart, total) = Tracker.dailyTotals(c, 1).first()
        val limitMin = Tracker.dailyLimitMin(c)
        val limitMs = limitMin * 60_000L
        val label = SimpleDateFormat("EEEE d/M", fa).format(Date(dayStart))
        val nf = NumberFormat.getInstance(fa)

        val sb = StringBuilder()
        sb.append("📱 گزارش استفاده‌ی امروز (").append(label).append(")\n")
        sb.append("⏱ مجموع: ").append(dur(total)).append("\n")
        if (limitMs > 0) {
            val pct = total * 100 / limitMs
            sb.append("🎯 سقف امروز: ").append(dur(limitMs)).append(" (").append(nf.format(pct)).append("٪)")
            if (total >= limitMs) sb.append(" ⚠️ از سقف گذشته")
            sb.append("\n")
        } else {
            sb.append("🎯 سقف امروز: تعیین نشده\n")
        }

        if (UsageSource.hasAccess(c)) {
            val pm = c.packageManager
            val top = UsageSource.todayPerApp(c).entries.sortedByDescending { it.value }.take(5)
            if (top.isNotEmpty()) {
                sb.append("\n🔝 پرمصرف‌ترین برنامه‌ها:\n")
                top.forEachIndexed { i, e ->
                    val name = runCatching { pm.getApplicationInfo(e.key, 0).loadLabel(pm).toString() }
                        .getOrDefault(e.key)
                    sb.append(nf.format(i + 1)).append(". ").append(name).append(" — ").append(dur(e.value)).append("\n")
                }
            }
        }
        return sb.toString().trim()
    }

    // ---------- زمان‌بندی ----------

    private fun dayKey(): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    /** از سرویس صدا زده می‌شود؛ بعد از ساعت تنظیم‌شده، روزی یک بار گزارش می‌فرستد. */
    fun tick(c: Context) {
        val now = System.currentTimeMillis()
        if (now - lastCheck < 60_000L) return
        lastCheck = now
        if (!configured(c)) return
        if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) < hour(c)) return
        val today = dayKey()
        if (sp(c).getString("sent_day", "") == today) return
        if (now - sp(c).getLong("last_try", 0L) < 5 * 60_000L) return   // بعد از شکست، هر ۵ دقیقه
        sp(c).edit().putLong("last_try", now).apply()

        val app = c.applicationContext
        exec.execute {
            runCatching {
                val r = sendNow(app, buildReport(app))
                if (r.first) sp(app).edit().putString("sent_day", today).apply()
            }
        }
    }

    /** وقتی زمان امروز به سقف رسید. */
    fun sendLimitReached(c: Context) {
        if (!configured(c)) return
        val app = c.applicationContext
        exec.execute {
            runCatching {
                val limMs = Tracker.dailyLimitMin(app) * 60_000L
                sendNow(app, "⚠️ سقف استفاده‌ی امروز (${dur(limMs)}) تموم شد.")
            }
        }
    }
}
