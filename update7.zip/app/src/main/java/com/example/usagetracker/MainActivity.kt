package com.example.usagetracker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Tracker.ensureRunning(this)   // ثبت خودکار، بدون سوییچ
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(
                    colorScheme = darkColorScheme(primary = Accent, background = Bg1, surface = Bg1)
                ) { Screen() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Tracker.ensureRunning(this)
    }
}

// ---------- پالت پاییزی ----------
private val Bg1 = Color(0xFF1A0E09)          // قهوه‌ای خیلی تیره
private val Bg2 = Color(0xFF2B1610)
private val Bg3 = Color(0xFF45200F)          // رنگ زنگ‌زده
private val NavBg = Color(0xFF21110A)
private val CardBg = Color(0xFF2E1A11)
private val CardBorder = Color(0xFF5A3420)
private val Track = Color(0xFF442817)
private val Accent = Color(0xFFFFA24C)       // نارنجی پاییزی
private val AccentDeep = Color(0xFFD9480F)   // نارنجی سوخته
private val Gold = Color(0xFFFFCF66)         // طلایی برگ
private val PastBar = Color(0xFF8A4B2A)
private val TextMain = Color(0xFFFFF1E0)
private val TextDim = Color(0xFFCDA98C)
private val Warn = Color(0xFFFFD43B)
private val Red = Color(0xFFFF6B6B)

private val fa = Locale("fa")

private fun fmt(ms: Long): String {
    val nf = NumberFormat.getInstance(fa)
    val m = ms / 60000
    val h = m / 60
    val mm = m % 60
    return when {
        m == 0L -> if (ms > 0) "کمتر از یک دقیقه" else "۰ دقیقه"
        h == 0L -> "${nf.format(mm)} دقیقه"
        else -> "${nf.format(h)} ساعت و ${nf.format(mm)} دقیقه"
    }
}

private fun clock(ms: Long): String {
    val nf = NumberFormat.getInstance(fa).apply { minimumIntegerDigits = 2; isGroupingUsed = false }
    val t = maxOf(ms, 0L) / 1000
    return "${nf.format(t / 3600)}:${nf.format(t % 3600 / 60)}:${nf.format(t % 60)}"
}

/** ساعت:دقیقه، مثل ۲:۱۵ */
private fun hm(ms: Long): String {
    val nh = NumberFormat.getInstance(fa).apply { isGroupingUsed = false }
    val nm = NumberFormat.getInstance(fa).apply { minimumIntegerDigits = 2; isGroupingUsed = false }
    val m = ms / 60000
    return "${nh.format(m / 60)}:${nm.format(m % 60)}"
}

private fun dayLetter(ms: Long): String {
    val d = Calendar.getInstance().apply { timeInMillis = ms }.get(Calendar.DAY_OF_WEEK)
    return when (d) {
        Calendar.SATURDAY -> "ش"
        Calendar.SUNDAY -> "ی"
        Calendar.MONDAY -> "د"
        Calendar.TUESDAY -> "س"
        Calendar.WEDNESDAY -> "چ"
        Calendar.THURSDAY -> "پ"
        else -> "ج"
    }
}

private val weekOrder = listOf(
    Calendar.SATURDAY to "شنبه", Calendar.SUNDAY to "یکشنبه", Calendar.MONDAY to "دوشنبه",
    Calendar.TUESDAY to "سه‌شنبه", Calendar.WEDNESDAY to "چهارشنبه",
    Calendar.THURSDAY to "پنجشنبه", Calendar.FRIDAY to "جمعه"
)

private data class Snap(
    val totals: List<Pair<Long, Long>>,
    val sessions: List<Pair<Long, Long>>,
    val openStart: Long,
    val usageOk: Boolean,
    val topApps: List<Triple<String, String, Long>>,
    val history: List<Pair<Long, Long>>
)

// ---------- اجزای ظاهری ----------

@Composable
private fun AppCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier.fillMaxWidth()
            .clip(shape)
            .background(CardBg.copy(alpha = 0.93f))
            .border(1.dp, CardBorder, shape)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

@Composable
private fun Ring(
    progress: Float,
    color: Color,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 14.dp.toPx()
            val tl = Offset(stroke / 2, stroke / 2)
            val sz = Size(size.width - stroke, size.height - stroke)
            drawArc(
                color = Track, startAngle = -90f, sweepAngle = 360f, useCenter = false,
                topLeft = tl, size = sz, style = Stroke(width = stroke)
            )
            if (progress > 0f) {
                drawArc(
                    color = color, startAngle = -90f, sweepAngle = 360f * progress, useCenter = false,
                    topLeft = tl, size = sz, style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, content = content)
    }
}

@Composable
private fun StepButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(42.dp, 34.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (enabled) Track else Track.copy(alpha = 0.5f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = if (enabled) Accent else TextDim, fontSize = 18.sp) }
}

@Composable
private fun PillButton(label: String, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(12.dp))
            .background(if (selected) Accent else Track.copy(alpha = if (enabled) 1f else 0.5f))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (selected) Color(0xFF2A1208) else if (enabled) Accent else TextDim,
            fontSize = 14.sp, fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun NavItem(
    emoji: String, label: String, selected: Boolean, badge: Boolean,
    modifier: Modifier = Modifier, onClick: () -> Unit
) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp))
            .background(if (selected) Accent.copy(alpha = 0.18f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box {
            Text(emoji, fontSize = 20.sp)
            if (badge) {
                Box(Modifier.align(Alignment.TopEnd).size(8.dp).clip(CircleShape).background(Warn))
            }
        }
        Text(
            label, color = if (selected) Accent else TextDim, fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier.clip(shape).background(CardBg.copy(alpha = 0.93f)).border(1.dp, CardBorder, shape).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(value, color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(title, color = TextDim, fontSize = 12.sp)
    }
}

/** برگ‌های پاییزی که آرام از بالا می‌افتند (پشت کارت‌ها). */
@Composable
private fun FallingLeaves(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "leaves")
    BoxWithConstraints(modifier) {
        val w = maxWidth.value
        val h = maxHeight.value
        val leaves = listOf("🍂", "🍁", "🍂", "🍁", "🍂", "🍁", "🍂")
        leaves.forEachIndexed { i, leaf ->
            val p by transition.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    tween(durationMillis = 12000 + i * 1900, easing = LinearEasing),
                    RepeatMode.Restart
                ),
                label = "leaf$i"
            )
            val x = w * (0.05f + 0.14f * i) + 22f * sin(p * 6.2832f * 2f + i)
            val y = -40f + p * (h + 80f)
            Text(
                leaf,
                fontSize = (18 + (i % 3) * 6).sp,
                modifier = Modifier.offset(x.dp, y.dp)
                    .rotate(p * 360f * (if (i % 2 == 0) 1f else -1f))
                    .alpha(0.22f)
            )
        }
    }
}

@Composable
private fun AppIcon(pkg: String) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        runCatching { ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
    }
    if (bmp != null) {
        Image(bmp, contentDescription = null, modifier = Modifier.size(34.dp))
    } else {
        Spacer(Modifier.size(34.dp))
    }
}

// ---------- صفحه‌ی اصلی ----------

@Composable
private fun Screen() {
    val ctx = LocalContext.current
    var snap by remember { mutableStateOf<Snap?>(null) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var batteryOk by remember { mutableStateOf(true) }
    var limits by remember { mutableStateOf(Tracker.allLimits(ctx)) }
    var editable by remember { mutableStateOf(Tracker.canEditSettings(ctx)) }
    var backupOk by remember { mutableStateOf(Backup.hasPermission()) }
    var tab by remember { mutableStateOf(0) }
    var histMode by remember { mutableStateOf(0) }
    var page by remember { mutableStateOf(0) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    LaunchedEffect(Unit) {
        while (true) {
            snap = withContext(Dispatchers.IO) {
                Backup.restoreIfNeeded(ctx)
                val usageOk = UsageSource.hasAccess(ctx)
                val pm = ctx.packageManager
                val top = if (usageOk) {
                    UsageSource.todayPerApp(ctx).entries
                        .sortedByDescending { it.value }
                        .take(5)
                        .map { (pkg, ms) ->
                            val label = runCatching { pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString() }
                                .getOrDefault(pkg)
                            Triple(pkg, label, ms)
                        }
                } else emptyList()
                Snap(
                    Tracker.dailyTotals(ctx), Tracker.todaySessions(ctx), Tracker.openStart(ctx),
                    usageOk, top, History.list(ctx)
                )
            }
            now = System.currentTimeMillis()
            batteryOk = ctx.getSystemService(PowerManager::class.java)
                .isIgnoringBatteryOptimizations(ctx.packageName)
            editable = Tracker.canEditSettings(ctx)
            limits = Tracker.allLimits(ctx)
            backupOk = Backup.hasPermission()
            delay(1000)
        }
    }

    val s = snap
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg1, Bg2, Bg3)))) {
        // درخشش گرم گوشه‌ی بالا
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    colors = listOf(Color(0x33FFA24C), Color.Transparent),
                    center = Offset(900f, 0f), radius = 1000f
                )
            )
        )
        FallingLeaves(Modifier.fillMaxSize())
        if (s == null) return@Box

        val active = s.openStart > 0L
        val total = s.totals.first().second
        val dow = Calendar.getInstance().apply { timeInMillis = now }.get(Calendar.DAY_OF_WEEK)
        val limit = limits[dow - 1]
        val limitMs = limit * 60_000L
        val over = limitMs > 0 && total >= limitMs
        val progress = if (limitMs > 0) (total.toFloat() / limitMs).coerceIn(0f, 1f) else 0f
        val ringColor = when {
            over -> Red
            progress >= 0.8f -> Warn
            else -> Accent
        }
        val settingsWarn = !batteryOk || !s.usageOk

        Column(Modifier.fillMaxSize().statusBarsPadding()) {

            // ----- سربرگ -----
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(painterResource(R.drawable.logo), contentDescription = null, modifier = Modifier.size(42.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("UsageTracker", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("ثبت زمان استفاده از گوشی", color = TextDim, fontSize = 12.sp)
                }
            }

            // ----- محتوای هر بخش (بدون اسکرول) -----
            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                when (tab) {

                    // ===== امروز =====
                    0 -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        AppCard {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Ring(progress, ringColor, Modifier.size(140.dp)) {
                                    Text(hm(total), color = TextMain, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                                    Text("امروز", color = TextDim, fontSize = 12.sp)
                                }
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        if (active) "جلسه‌ی فعلی" else "گوشی قفل است",
                                        color = TextDim, fontSize = 13.sp
                                    )
                                    if (active) {
                                        Text(
                                            clock(now - s.openStart), color = Gold,
                                            fontSize = 30.sp, fontWeight = FontWeight.Bold
                                        )
                                    }
                                    if (limitMs > 0) {
                                        if (over) {
                                            Text("از سقف گذشته: ${fmt(total - limitMs)}", color = Red, fontSize = 14.sp)
                                        } else {
                                            Text("مانده تا سقف: ${fmt(limitMs - total)}", color = TextMain, fontSize = 14.sp)
                                        }
                                    } else {
                                        Text("سقف امروز تعیین نشده", color = TextDim, fontSize = 13.sp)
                                    }
                                }
                            }
                        }

                        AppCard {
                            Text(
                                "پرمصرف‌ترین برنامه‌های امروز", color = TextMain,
                                fontSize = 16.sp, fontWeight = FontWeight.Bold
                            )
                            if (!s.usageOk) {
                                Text(
                                    "برای دیدن مصرف هر برنامه، دسترسی «Usage access» رو از بخش تنظیمات بده.",
                                    color = Warn, fontSize = 13.sp
                                )
                            } else if (s.topApps.isEmpty()) {
                                Text("هنوز مصرفی ثبت نشده", color = TextDim)
                            } else {
                                val topMax = s.topApps.first().third.coerceAtLeast(1L)
                                s.topApps.forEach { (pkg, label, ms) ->
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        AppIcon(pkg)
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text(label, color = TextMain, fontSize = 14.sp)
                                            Box(
                                                Modifier.fillMaxWidth().height(5.dp)
                                                    .clip(RoundedCornerShape(3.dp)).background(Track)
                                            ) {
                                                Box(
                                                    Modifier.fillMaxWidth((ms.toFloat() / topMax).coerceIn(0.03f, 1f))
                                                        .fillMaxHeight()
                                                        .clip(RoundedCornerShape(3.dp))
                                                        .background(Brush.horizontalGradient(listOf(AccentDeep, Gold)))
                                                )
                                            }
                                        }
                                        Spacer(Modifier.width(10.dp))
                                        Text(fmt(ms), color = Accent, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }

                    // ===== هفته =====
                    1 -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        val days = s.totals.asReversed()          // قدیمی‌ترین راست، امروز چپ
                        fun limitOf(dayStart: Long): Long {
                            val d = Calendar.getInstance().apply { timeInMillis = dayStart }.get(Calendar.DAY_OF_WEEK)
                            return limits[d - 1] * 60_000L
                        }
                        AppCard {
                            Text("۷ روز اخیر", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            val scaleMax = maxOf(days.maxOf { it.second }, days.maxOf { limitOf(it.first) })
                                .coerceAtLeast(60_000L)
                            val barMax = 100f

                            Row(Modifier.fillMaxWidth().height(130.dp)) {
                                days.forEachIndexed { i, (day, ms) ->
                                    val isToday = i == days.lastIndex
                                    val lim = limitOf(day)
                                    val h = if (ms <= 0L) 3f else (barMax * ms / scaleMax).coerceAtLeast(6f)
                                    val brush = when {
                                        lim > 0 && ms > lim -> Brush.verticalGradient(listOf(Red, Color(0xFFB91C1C)))
                                        isToday -> Brush.verticalGradient(listOf(Gold, AccentDeep))
                                        else -> Brush.verticalGradient(listOf(Color(0xFFB5651D), PastBar))
                                    }
                                    Box(Modifier.weight(1f).fillMaxHeight()) {
                                        Column(
                                            Modifier.fillMaxSize(),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Bottom
                                        ) {
                                            if (ms >= 60_000L) {
                                                Text(hm(ms), color = if (isToday) Gold else TextDim, fontSize = 10.sp)
                                            }
                                            Spacer(Modifier.height(3.dp))
                                            Box(
                                                Modifier.width(22.dp).height(h.dp)
                                                    .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                                    .background(brush)
                                            )
                                        }
                                        if (lim > 0) {
                                            Box(
                                                Modifier.align(Alignment.BottomCenter)
                                                    .offset(y = (-(barMax * lim / scaleMax)).dp)
                                                    .width(32.dp).height(2.dp)
                                                    .background(Warn)
                                            )
                                        }
                                    }
                                }
                            }
                            Row(Modifier.fillMaxWidth()) {
                                days.forEachIndexed { i, (day, _) ->
                                    Text(
                                        dayLetter(day), Modifier.weight(1f), textAlign = TextAlign.Center,
                                        color = if (i == days.lastIndex) Gold else TextDim, fontSize = 12.sp
                                    )
                                }
                            }
                            if (days.any { limitOf(it.first) > 0 }) {
                                Text("خط زرد: سقف همون روز", color = Warn, fontSize = 12.sp)
                            }
                        }

                        val sum = days.sumOf { it.second }
                        val avg = sum / days.size
                        val best = days.maxByOrNull { it.second }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatCard("مجموع هفته", hm(sum), Modifier.weight(1f))
                            StatCard("میانگین روزانه", hm(avg), Modifier.weight(1f))
                            StatCard(
                                if (best != null && best.second > 0)
                                    SimpleDateFormat("EEEE", fa).format(Date(best.first)) else "پرمصرف‌ترین روز",
                                hm(best?.second ?: 0L), Modifier.weight(1f)
                            )
                        }
                        Text("(ساعت:دقیقه)", color = TextDim, fontSize = 11.sp, modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center)
                    }

                    // ===== سقف =====
                    2 -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        AppCard {
                            Text(
                                "سقف استفاده‌ی هر روز هفته", color = TextMain,
                                fontSize = 16.sp, fontWeight = FontWeight.Bold
                            )
                            weekOrder.forEach { (d, name) ->
                                val v = limits[d - 1]
                                val isToday = d == dow
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        name, modifier = Modifier.width(78.dp),
                                        color = if (isToday) Gold else TextMain,
                                        fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal
                                    )
                                    StepButton("−", editable) {
                                        val n = (v - 15).coerceAtLeast(0)
                                        if (Tracker.setLimitFor(ctx, d, n)) limits = Tracker.allLimits(ctx)
                                    }
                                    Text(
                                        if (v == 0) "بدون سقف" else fmt(v * 60_000L),
                                        modifier = Modifier.weight(1f), textAlign = TextAlign.Center,
                                        color = TextMain, fontSize = 15.sp
                                    )
                                    StepButton("+", editable) {
                                        val n = (v + 15).coerceAtMost(720)
                                        if (Tracker.setLimitFor(ctx, d, n)) limits = Tracker.allLimits(ctx)
                                    }
                                }
                            }
                            if (editable) {
                                Text("الان می‌تونی سقف همه‌ی روزهای هفته رو تنظیم کنی.", color = Gold, fontSize = 12.sp)
                            } else {
                                Text(
                                    "تنظیم سقف هفته فقط پنجشنبه‌ها از ساعت ۱۴ تا ۱۶ ممکنه " +
                                        "(تاریخ و ساعت گوشی باید روی «خودکار» باشه).",
                                    color = Warn, fontSize = 12.sp
                                )
                            }
                            Text(
                                "وقتی زمان امروز به سقف همون روز برسه، هشدار نشون داده می‌شه.",
                                color = TextDim, fontSize = 12.sp
                            )
                        }
                    }

                    // ===== تاریخچه =====
                    3 -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        val todayStart = s.totals.first().first
                        val hmFmt = SimpleDateFormat("HH:mm", fa)
                        val df = SimpleDateFormat("EEEE d/M", fa)
                        val items: List<Pair<String, String>> = if (histMode == 0) {
                            s.sessions.asReversed().mapIndexed { idx, (a, b) ->
                                val label = if (active && idx == 0) "${hmFmt.format(Date(a))} تا اکنون"
                                else "${hmFmt.format(Date(a))} تا ${hmFmt.format(Date(b))}"
                                label to fmt(b - a)
                            }
                        } else {
                            s.history.filter { it.first < todayStart }.map { (d, ms) -> df.format(Date(d)) to fmt(ms) }
                        }
                        val pageSize = 6
                        val pages = maxOf(1, (items.size + pageSize - 1) / pageSize)
                        val p = page.coerceIn(0, pages - 1)
                        val nf = NumberFormat.getInstance(fa)

                        AppCard {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                PillButton("جلسه‌های امروز", histMode == 0) { histMode = 0; page = 0 }
                                PillButton("روزهای قبل", histMode == 1) { histMode = 1; page = 0 }
                            }
                            if (items.isEmpty()) {
                                Text(
                                    if (histMode == 0) "هنوز جلسه‌ای ثبت نشده" else "هنوز روز قبلی ثبت نشده",
                                    color = TextDim
                                )
                            } else {
                                items.drop(p * pageSize).take(pageSize).forEach { (l, v) ->
                                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                                        Text(l, color = TextMain, modifier = Modifier.weight(1f))
                                        Text(v, color = Accent)
                                    }
                                }
                            }
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                PillButton("قبلی", false, p > 0) { page = p - 1 }
                                Text("صفحه ${nf.format(p + 1)} از ${nf.format(pages)}", color = TextDim, fontSize = 13.sp)
                                PillButton("بعدی", false, p < pages - 1) { page = p + 1 }
                            }
                        }
                    }

                    // ===== تنظیمات =====
                    else -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        AppCard {
                            Text("کار در پس‌زمینه", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            if (batteryOk) {
                                Text("✓ محدودیت باتری برداشته شده.", color = Gold, fontSize = 13.sp)
                            } else {
                                Text(
                                    "برای کار در پس‌زمینه، محدودیت باتری باید برداشته بشه.",
                                    color = Warn, fontSize = 13.sp
                                )
                                PillButton("اجازه دادن", true) {
                                    ctx.startActivity(
                                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                                            .setData(Uri.parse("package:${ctx.packageName}"))
                                    )
                                }
                            }
                        }

                        AppCard {
                            Text("آمار سیستم", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            if (s.usageOk) {
                                Text("✓ دسترسی «Usage access» فعاله.", color = Gold, fontSize = 13.sp)
                            } else {
                                Text(
                                    "برای اینکه آمار مثل Digital Wellbeing باشه و مصرف هر برنامه دیده بشه، دسترسی «Usage access» رو بده.",
                                    color = Warn, fontSize = 13.sp
                                )
                                PillButton("دادن دسترسی", true) {
                                    ctx.startActivity(
                                        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                                            .setData(Uri.parse("package:${ctx.packageName}"))
                                    )
                                }
                            }
                        }

                        if (Build.VERSION.SDK_INT >= 30) {
                            AppCard {
                                Text("پشتیبان‌گیری", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                if (backupOk) {
                                    Text(
                                        "✓ فعاله. اطلاعات توی پوشه‌ی Documents/UsageTracker ذخیره می‌شه و اگه برنامه پاک و دوباره نصب بشه، " +
                                            "بعد از دادن همین دسترسی خودش برمی‌گرده.",
                                        color = Gold, fontSize = 13.sp
                                    )
                                } else {
                                    Text(
                                        "برای اینکه اطلاعات بعد از حذف برنامه هم بمونه، دسترسی «همه‌ی فایل‌ها» لازمه.",
                                        color = Warn, fontSize = 13.sp
                                    )
                                    PillButton("دادن دسترسی", true) {
                                        ctx.startActivity(
                                            Intent(
                                                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                                Uri.parse("package:${ctx.packageName}")
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ----- نوار پایین (دکمه‌ها) + فوتر -----
            val navShape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
            Column(
                Modifier.fillMaxWidth().clip(navShape).background(NavBg).border(1.dp, CardBorder, navShape)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    NavItem("🍁", "امروز", tab == 0, false, Modifier.weight(1f)) { tab = 0 }
                    NavItem("📊", "هفته", tab == 1, false, Modifier.weight(1f)) { tab = 1 }
                    NavItem("🎯", "سقف", tab == 2, false, Modifier.weight(1f)) { tab = 2 }
                    NavItem("🕘", "تاریخچه", tab == 3, false, Modifier.weight(1f)) { tab = 3; page = 0 }
                    NavItem("⚙️", "تنظیمات", tab == 4, settingsWarn, Modifier.weight(1f)) { tab = 4 }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(CardBorder.copy(alpha = 0.6f)))
                Column(
                    Modifier.fillMaxWidth().padding(vertical = 7.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("🍁 تقدیم به بچه‌های خوب آکادمی مهفا 🍁", color = Gold, fontSize = 12.sp)
                    Text("از طرف پویا نادر", color = TextDim, fontSize = 11.sp)
                }
            }
        }
    }
}
