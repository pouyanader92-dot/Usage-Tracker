package com.example.usagetracker

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.Calendar

class UsageDb(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "usage.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "start_ms INTEGER NOT NULL, end_ms INTEGER NOT NULL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun insert(start: Long, end: Long) {
        if (end <= start) return
        writableDatabase.insert("sessions", null, ContentValues().apply {
            put("start_ms", start)
            put("end_ms", end)
        })
    }

    fun since(ms: Long): List<Pair<Long, Long>> {
        val out = ArrayList<Pair<Long, Long>>()
        readableDatabase.rawQuery(
            "SELECT start_ms, end_ms FROM sessions WHERE end_ms > ?", arrayOf(ms.toString())
        ).use { c -> while (c.moveToNext()) out.add(c.getLong(0) to c.getLong(1)) }
        return out
    }
}

/** منطق ثبت جلسه‌ها؛ هم سرویس و هم صفحه‌ی اصلی از اینجا استفاده می‌کنند. */
object Tracker {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("tracker", Context.MODE_PRIVATE)

    fun isEnabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()
    private fun openStart(c: Context) = sp(c).getLong("open_start", 0L)
    private fun setOpenStart(c: Context, v: Long) = sp(c).edit().putLong("open_start", v).apply()

    @Synchronized
    fun begin(c: Context) {
        if (openStart(c) == 0L) setOpenStart(c, System.currentTimeMillis())
    }

    @Synchronized
    fun end(c: Context) {
        val s = openStart(c)
        if (s > 0L) {
            UsageDb(c).insert(s, System.currentTimeMillis())
            setOpenStart(c, 0L)
        }
    }

    /** جمع مدت استفاده برای n روز اخیر؛ اولین عنصر امروز است. */
    fun dailyTotals(c: Context, days: Int = 7): List<Pair<Long, Long>> {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val starts = ArrayList<Long>()
        repeat(days) {
            starts.add(cal.timeInMillis)
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        val sessions = UsageDb(c).since(starts.last()).toMutableList()
        val open = openStart(c)
        if (open > 0L) sessions.add(open to now)

        return starts.map { dayStart ->
            val cal2 = Calendar.getInstance().apply { timeInMillis = dayStart; add(Calendar.DAY_OF_YEAR, 1) }
            val dayEnd = cal2.timeInMillis
            val total = sessions.sumOf { (s, e) ->
                val a = maxOf(s, dayStart)
                val b = minOf(e, dayEnd)
                if (b > a) b - a else 0L
            }
            dayStart to total
        }
    }
}
