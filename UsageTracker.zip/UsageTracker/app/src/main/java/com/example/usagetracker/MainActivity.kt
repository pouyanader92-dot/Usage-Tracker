package com.example.usagetracker

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme { Screen() }
            }
        }
    }
}

private val fa = Locale("fa")

private fun fmt(ms: Long): String {
    val nf = NumberFormat.getInstance(fa)
    val m = ms / 60000
    val h = m / 60
    val mm = m % 60
    return if (h == 0L) "${nf.format(mm)} دقیقه" else "${nf.format(h)} ساعت و ${nf.format(mm)} دقیقه"
}

@Composable
private fun Screen() {
    val ctx = LocalContext.current
    var enabled by remember { mutableStateOf(Tracker.isEnabled(ctx)) }
    var totals by remember { mutableStateOf(Tracker.dailyTotals(ctx)) }

    LaunchedEffect(Unit) {
        while (true) {
            totals = Tracker.dailyTotals(ctx)
            delay(5000)
        }
    }

    fun start() {
        Tracker.setEnabled(ctx, true)
        ctx.startForegroundService(Intent(ctx, TrackerService::class.java))
        enabled = true
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { start() }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(20.dp).statusBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("زمان استفاده از گوشی", fontSize = 24.sp)

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("فعال‌سازی ثبت", Modifier.weight(1f))
                Switch(checked = enabled, onCheckedChange = { on ->
                    if (on) {
                        if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        else start()
                    } else {
                        Tracker.setEnabled(ctx, false)
                        ctx.stopService(Intent(ctx, TrackerService::class.java))
                        Tracker.end(ctx)
                        enabled = false
                    }
                })
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("امروز")
                    Text(fmt(totals.first().second), fontSize = 28.sp)
                }
            }

            Text("۷ روز اخیر")
            val dayFmt = SimpleDateFormat("EEEE d/M", fa)
            totals.forEach { (day, ms) ->
                Row(Modifier.fillMaxWidth()) {
                    Text(dayFmt.format(Date(day)), Modifier.weight(1f))
                    Text(fmt(ms))
                }
            }

            Spacer(Modifier.weight(1f))
            OutlinedButton(
                onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                            .setData(Uri.parse("package:${ctx.packageName}"))
                    )
                },
                modifier = Modifier.fillMaxWidth().navigationBarsPadding()
            ) { Text("جلوگیری از بسته شدن برنامه (بهینه‌سازی باتری)") }
        }
    }
}
